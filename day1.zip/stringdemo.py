# this is single line comment
print(10,20,30,40)
print("python","java","oracle",10)
print(10,20,30,40)
print("python","java","oracle",10)


val = 10
print(val)
print("Value is ",val)



name = "python"
print(name)
print("I love",name)


