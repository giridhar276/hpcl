# list demo



alist = [10,20,56,4]

blist = ["python","java","oracle"]
clist = [45,4.4,"python"]


print(alist)

print("list elements are", alist)

print("first element", alist[0])
print("second element", alist[1])



alist[0] = 10000
print("After updating", alist)




