

# set methods

aset = {10,20,30}
bset = {30,40,50}

# unique values
print(aset.union(bset))

# common values
print(aset.intersection(bset))