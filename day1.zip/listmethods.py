


alist = [54,34,23,67,12,23,76]
## adding element at the end of the list
alist.append(100)
print("After appending ",alist)

alist.append(1)
print("After appending ",alist)


print(alist.count(23))


# remove element
alist.pop(1)  # value(34) at the index 1 will be removed
print("After pop ", alist)

# will remove the value directly
alist.remove(100)
print("After remove ", alist)


## alist.insert(where,what)
alist.insert(0,1000)
print("After inserting ", alist)

alist.insert(5,1000)
print("After inserting ", alist)


