'''
tuple  ( READ ONLY , unchangable , immutable )
tuple contains set of elements.
Elements can be set of numbers or strings or any combination.
tuple elements are defined in ().
tuple is immutable by default.
***** Elements inside tuple cannot be modified *******
'''


atup = (10,20,30,40)

btup = ("python","java",56)

print(atup)
print("values are", atup)


#atup[3] = 100

print("After replacing",atup)