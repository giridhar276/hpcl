
name = "python programming"
print(name.upper())
print(name.lower())

print(name.isupper())
print(name.islower())


print(name.replace("python","ruby"))

print(name.startswith("z"))
print(name.startswith("p"))
print(name.endswith("g"))

print(name.split(" "))

print(name.count("p"))



a = 10
b = 20
if a < b :
    print("A is less than B")
else:
    print("B is less than A")
    
    
    
name = "python programming"
if name.isupper():
    print("String is defined in upper")
else:
    print("String is defined in lower")
    


if name.startswith("p") :
    print("Yes.. string is starting with p")
else:
    print("string is starting with something else")







