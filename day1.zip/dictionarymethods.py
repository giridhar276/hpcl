
book  = {"chap1":10 ,"chap2":20 ,"chap3":30 ,"chap1":1000}


print(book)

# display ONLY keys
print(book.keys())


# display ONLY values
print(book.values())


## display both keys:value
print(book.items())   # list of tuples





